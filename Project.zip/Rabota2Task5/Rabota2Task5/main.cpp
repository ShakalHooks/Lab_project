#include <iostream>
using namespace std;

int main() {

    setlocale(LC_ALL, "Russian");

    int X[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    int Y[15] = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };

    int A[5][5] = { 0 };
    int indexX = 0, indexY = 0;

    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (i + j < 4) {
                if (indexX < 10) {
                    A[i][j] = X[indexX++];
                }
            }
            else {
                if (indexY < 15) {
                    A[i][j] = Y[indexY++];
                }
            }
        }
    }

    cout << "������� A(5,5):" << endl;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            cout << A[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
