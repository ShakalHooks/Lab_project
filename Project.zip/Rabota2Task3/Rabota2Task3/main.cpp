#include <iostream>
using namespace std;

int main() {

    setlocale(LC_ALL, "Russian");

    int X[14] = { 0, 3, 1, 5, 2, 0, 4, 1, 6, 3, 1, 2, 0, 7 };

    for (int i = 0; i < 14; ++i) {
        if (X[i] < 2) {
            X[i] = 0;
        }
    }

    cout << "���������� ������: ";
    for (int i = 0; i < 14; ++i) {
        cout << X[i] << " ";
    }
    cout << endl;

    return 0;
}
