#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>

std::vector<int> generateRandomArray(int size, int min, int max) {
    std::vector<int> array(size);
    for (int i = 0; i < size; ++i) {
        array[i] = rand() % (max - min + 1) + min;
    }
    return array;
}

void bubbleSort(std::vector<int>& array) {
    int n = array.size();
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                std::swap(array[j], array[j + 1]);
            }
        }
    }
}

void insertionSort(std::vector<int>& array) {
    int n = array.size();
    for (int i = 1; i < n; ++i) {
        int key = array[i];
        int j = i - 1;
        while (j >= 0 && array[j] > key) {
            array[j + 1] = array[j];
            j = j - 1;
        }
        array[j + 1] = key;
    }
}

void selectionSort(std::vector<int>& array) {
    int n = array.size();
    for (int i = 0; i < n - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (array[j] < array[minIndex]) {
                minIndex = j;
            }
        }
        std::swap(array[i], array[minIndex]);
    }
}

void shakerSort(std::vector<int>& array) {
    int n = array.size();
    bool swapped = true;
    int start = 0;
    int end = n - 1;
    while (swapped) {
        swapped = false;
        for (int i = start; i < end; ++i) {
            if (array[i] > array[i + 1]) {
                std::swap(array[i], array[i + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
        swapped = false;
        --end;
        for (int i = end - 1; i >= start; --i) {
            if (array[i] > array[i + 1]) {
                std::swap(array[i], array[i + 1]);
                swapped = true;
            }
        }
        ++start;
    }
}

void shellSort(std::vector<int>& array) {
    int n = array.size();
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; ++i) {
            int temp = array[i];
            int j;
            for (j = i; j >= gap && array[j - gap] > temp; j -= gap) {
                array[j] = array[j - gap];
            }
            array[j] = temp;
        }
    }
}

int partition(std::vector<int>& array, int low, int high) {
    int pivot = array[high];
    int i = (low - 1);
    for (int j = low; j <= high - 1; ++j) {
        if (array[j] < pivot) {
            ++i;
            std::swap(array[i], array[j]);
        }
    }
    std::swap(array[i + 1], array[high]);
    return (i + 1);
}

void quickSort(std::vector<int>& array, int low, int high) {
    if (low < high) {
        int pi = partition(array, low, high);
        quickSort(array, low, pi - 1);
        quickSort(array, pi + 1, high);
    }
}

template <typename SortFunction>
double measureSortTime(SortFunction sortFunc, std::vector<int> array) {
    auto start = std::chrono::high_resolution_clock::now();
    sortFunc(array);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;
    return duration.count();
}

int main() {

    setlocale(LC_ALL, "Russian");
    srand(time(0));
    int arraySize = 1000;
    std::vector<int> array = generateRandomArray(arraySize, 0, 100);

    std::vector<int> bubbleArray = array;
    std::vector<int> insertionArray = array;
    std::vector<int> selectionArray = array;
    std::vector<int> shakerArray = array;
    std::vector<int> shellArray = array;
    std::vector<int> quickArray = array;

    double bubbleTime = measureSortTime(bubbleSort, bubbleArray);
    double insertionTime = measureSortTime(insertionSort, insertionArray);
    double selectionTime = measureSortTime(selectionSort, selectionArray);
    double shakerTime = measureSortTime(shakerSort, shakerArray);
    double shellTime = measureSortTime(shellSort, shellArray);
    double quickTime = measureSortTime([](std::vector<int>& arr) { quickSort(arr, 0, arr.size() - 1); }, quickArray);

    std::cout << "���������� ������� ������� ������: " << bubbleTime << " seconds\n";
    std::cout << "���������� ������� ������� ���������: " << insertionTime << " seconds\n";
    std::cout << "���������� ������� ������� ������: " << selectionTime << " seconds\n";
    std::cout << "��������� ����������: " << shakerTime << " seconds\n";
    std::cout << "���������� ������� �����: " << shellTime << " seconds\n";
    std::cout << "���������� ������� �����: " << quickTime << " seconds\n";

    return 0;
}