#include <iostream>
#include <queue>
#include <unordered_map>
#include <vector>
#include <bitset>

using namespace std;

struct Node {
    char ch;
    int freq;
    Node* left;
    Node* right;

    Node(char c, int f) : ch(c), freq(f), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* left, Node* right) {
        return left->freq > right->freq;
    }
};

Node* buildHuffmanTree(const unordered_map<char, int>& freqMap) {
    priority_queue<Node*, vector<Node*>, Compare> pq;

    for (auto& pair : freqMap) {
        pq.push(new Node(pair.first, pair.second));
    }

    while (pq.size() > 1) {
        Node* left = pq.top();
        pq.pop();
        Node* right = pq.top();
        pq.pop();

        Node* newNode = new Node('\0', left->freq + right->freq);
        newNode->left = left;
        newNode->right = right;
        pq.push(newNode);
    }

    return pq.top();
}

void generateCodes(Node* root, const string& str, unordered_map<char, string>& huffmanCodes) {
    if (!root) return;

    if (root->ch != '\0') {
        huffmanCodes[root->ch] = str;
    }

    generateCodes(root->left, str + "0", huffmanCodes);
    generateCodes(root->right, str + "1", huffmanCodes);
}

string compressText(const string& text, unordered_map<char, string>& huffmanCodes) {
    string compressed = "";
    for (char c : text) {
        compressed += huffmanCodes[c];
    }
    return compressed;
}

string decompressText(const string& compressed, Node* root) {
    string decompressed = "";
    Node* current = root;

    for (char bit : compressed) {
        if (bit == '0') {
            current = current->left;
        }
        else {
            current = current->right;
        }

        if (current->left == nullptr && current->right == nullptr) {
            decompressed += current->ch;
            current = root;
        }
    }
    return decompressed;
}

int main() {

    setlocale(LC_ALL, "RUSSIAN");

    string text = "nikita decided to test this example for Huffman coding";

    unordered_map<char, int> freqMap;
    for (char c : text) {
        freqMap[c]++;
    }

    Node* root = buildHuffmanTree(freqMap);

    unordered_map<char, string> huffmanCodes;
    generateCodes(root, "", huffmanCodes);

    cout << "Huffman ���:" << endl;
    for (auto& pair : huffmanCodes) {
        cout << pair.first << ": " << pair.second << endl;
    }

    string compressed = compressText(text, huffmanCodes);
    cout << "\n������ ����� (� �������� �������): " << compressed << endl;

    string decompressed = decompressText(compressed, root);
    cout << "\n������������� �����: " << decompressed << endl;

    return 0;
}